# MR X opening (Danny Phantom style) - pakej

- `originals/` : 20 gambar asal (nama fail asal, ikut susunan dihantar)
- `intro/assets/` : gambar yang dipakai, nama ikut fungsi (lab, walk1, crouch, green, kick ...)
- `intro/intro.html` : timeline versi HTML/JS (rujukan masa & susunan). Render: `node intro/render.js` (perlu playwright + ffmpeg)

## Storyboard (34s, 16:9)
1. 0-4.5s  Makmal ungu, neon X, zoom perlahan - `lab` (99476)
2. 4.5-8.5s  Dia berjalan, panel cerah - `walk1`,`walk3`,`walk2`
3. 8.5-10.6s  Flash, mencangkung, cincin kejutan ungu - `crouch` (99397)
4. 10.6-13.2s  Bentuk kuasa hijau - `green` (99394)
5. 13.2-14.6s  Close-up mata cyan bertopeng - `mask-eyes` (99447)
6. 14.6-25.5s  Montaj aksi, potongan pantas, speed line: stance, kick, punch, blast, guard, land, fist, fly-back, fly, float
7. 26.1-34s  Peluk tubuh di kanan, tajuk "MR X" + "ANIMATION" di kiri, fade out - `arms-crossed` (99425)

Belum siap: audio (tema + SFX), animasi watak sebenar (kini pose statik + kesan).
